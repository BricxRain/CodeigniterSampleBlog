<h2><?php echo $title; ?></h2>
<p>This is Bricx Blog ersion 1.0</p>
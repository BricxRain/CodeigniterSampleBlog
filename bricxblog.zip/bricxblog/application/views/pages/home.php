<h2><?php echo $title; ?></h2>
<p>Welcome to Bricx Blog Application</p>
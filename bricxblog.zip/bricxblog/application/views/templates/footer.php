</div>

<script>
    CKEDITOR.replace( 'body' );
</script>

</body>
</html>